function abrirMenu() {
    document.getElementById("menu").style.width = "100%";
}

function fecharMenu() {
    document.getElementById("menu").style.width = "0px";
}