package br.com.monitotem.test;

import br.com.monitotem.service.Log;

/**
 *
 * @author Karina
 */
public class TestLog {
 
    public static void main(String[] args) {
        
        
        Log presunto = new Log();
        
        presunto.logar("Deu certo!!");
    }
    
    
    
    
}
