/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.monitotem.test;

import org.silentsoft.slack.api.SlackAPI;

public class TesteSlack {
    
    public static void main(String[] args) throws Exception {
        
            SlackAPI.postMessage("xoxb-3431609768566-3438312290354-SjIa9U1TQ9sTKVP0frsUU6JB", "usuarios", "Voce logou");
        
        
    }
    
}
